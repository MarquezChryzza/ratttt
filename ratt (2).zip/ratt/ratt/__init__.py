import pymysql


#pymysql.install_as_MySQLdb()

#Connection = pymysql.connect(host='localhost', user='admin', password='thesis123', 
#             db='thesis',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor )
#Connection.execute
#Connection.close()

